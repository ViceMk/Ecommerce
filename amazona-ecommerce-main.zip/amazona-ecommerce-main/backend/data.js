const bcrytp=require('bcryptjs')

const data={

   products:[
        {
        _id:1,
        name:"Iphone X",
        category:"Phones",
        image:"/images/p1.jpg",
        price:120,
        brand:"Apple",
        rating:4.5,
        numReviews:10,
        description:"high quality product",
        countInStock:22

    },
     {
        _id:2,
        name:"HP Laptop",
        category:"Laptops",
        image:"/images/p2.jpg",
        price:120,
        brand:"HP",
        rating:3,
        numReviews:15,
        description:"high quality product",
        countInStock:2

    },
     {
        _id:3,
        name:"Huawei Laptop",
        category:"Laptops",
        image:"/images/p3.jpg",
        price:140,
        brand:"Huawei",
        rating:5,
        numReviews:12,
        description:"high quality product",
        countInStock:12

     },
      {
        _id:4,
        name:"Iphone 6",
        category:"Phones",
        image:"/images/p4.jpg",
        price:110,
        brand:"Apple",
        rating:4,
        numReviews:8,
        description:"high quality product",
        countInStock:0

    },
     {
        _id:5,
        name:"Acer Laptop",
        category:"Laptops",
        image:"/images/p5.jpg",
        price:130,
        brand:"Acer",
        rating:5,
        numReviews:30,
        description:"high quality product",
        countInStock:9
    },
     {
        _id:6,
        name:"Huawei Xtreme",
        category:"Phones",
        image:"/images/p6.jpg",
        price:140,
        brand:"Huawei",
        rating:3.5,
        numReviews:11,
        description:"high quality product",
        countInStock:0
    }
    ]
}
    


module.exports=data;