##ECOMMERCE WEB APPLICATION

-This a Javascript full stack application, that allows users to view and purchase products online using the PayPal payment gateaway. It's divided into two main components, the Admin and customer sides.

-Admin has more previleges in the application such as updating products, and other operations.

-Use should sign in or sign up to be able to purchase any products.

##TECHNOLOGIES USED

FRONTEND
-React.js, Redux, CSS, PAYPAL

BACKEND
-Node.js, Express, Mongoose, Multer, MongoDB



![Screenshot (92)](https://user-images.githubusercontent.com/61283803/121271102-3e0ab880-c8c3-11eb-9c46-f1426060fa9c.png)

![Screenshot (140)](https://user-images.githubusercontent.com/61283803/121271105-3ea34f00-c8c3-11eb-9ca3-1a96366e94a4.png)
