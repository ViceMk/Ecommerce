import React from 'react'

function Page404() {
    return (
        <div>
            <h1>PAGE NOT FOUND</h1>
            <h1>ERROR 404</h1>
        </div>
    )
}

export default Page404
